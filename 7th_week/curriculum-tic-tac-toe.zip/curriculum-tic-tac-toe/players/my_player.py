from logic import *

def get_move(board, letter):
   # ['X','','','','','','','',''] , 'O'
   # 0 - 8
   # STEP 1
   weights = [5, 1, 5, 
               1, 4, 1, 
               5, 1, 5]
   if (len(get_available_moves(board)) % 2) != 0:
      weights = [5, 1, 5, 
               1, 4, 1, 
               5, 1, 5]
      if ((board[4] == 'O' and board[2] == 'O') or (board[4] == 'O' and board[6] == 'O') or (board[4] == 'O' and board [8] == 'O')) and board[3] == '':
         weights = [5, 1, 5, 
                  1, 4, 1, 
                  5, 1, 5]
      elif board[4] == 'O':
         weights = [1, 5, 1, 
                  5, 4, 5, 
                  1, 5, 1]
         
         
         
   if (len(get_available_moves(board)) % 2) == 0:
      my_list = [0, 1, 2, 3, 4, 5, 6, 7, 8]
      weights = [1, 4, 1, 
               4, 5, 4, 
               1, 4, 1]
      choice = defense_positions(board)
      if choice in my_list:
         weights[choice] = 9
      else:
         weights = [1, 4, 1, 
                    4, 5, 4, 
                    1, 4, 1]
      
      
   available_moves = get_available_moves(board)
   
   
   # STEP 2
   move_scores = [0] * 9  # [0, 1, 1, 1, 1, 1, 1, 1, 1]
   # available_moves = [1, 2, 3, 4, 5, 6, 7, 8]
   for move_index in available_moves:
      move_scores[move_index] = get_score(board, letter, move_index)
   
   # STEP 3
   move_weighted_scores = []
   for i in range(9):
      move_weighted_scores.append(weights[i] * move_scores[i]) #[0, 1, 1, 1, 1, 1, 1, 1, 1]
                                                               #[5, 1, 5, 1, 4, 1, 5, 1, 5]
                                                               #[0, 1, 5, 1, 4, 1, 5, 1, 5]
   

   
   # STEP 4
   return get_highest_index(move_weighted_scores)

def get_score(board, letter, move):
   temp_board = board[::]

   temp_board[move] = letter
   
   winner = get_winner(temp_board)

   if winner == '':
      return 1
   if winner == letter:
      return 50
   
   return -1

def get_highest_index(list_of_numbers):
   max_index = -1
   max_n = -1
   for i, n in enumerate(list_of_numbers):
      if n > max_n:
         max_index = i
         max_n = n

   return max_index

def get_available_moves(board):
   # ['X','','','','','','','','']
   output = []
   for i in range(9):   # 0-8
      if board[i] == '':
         output.append(i)

   return output  # [1, 2, 3, 4, 5, 6, 7, 8]




def defense_positions(board):
   checks = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6]
   ]
   for indexes in checks:
      if board[indexes[0]] == board[indexes[1]] != '':
         if board[indexes[2]] == '':
            return indexes[2]
      if board[indexes[0]] == board[indexes[2]] != '':
         if board[indexes[1]] == '':
            return indexes[1]
      if board[indexes[1]] == board[indexes[2]] != '':
         if board[indexes[0]] == '':
            return indexes[0]
   
   return ''